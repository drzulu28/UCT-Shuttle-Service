function exitWebPage() {
    window.location.href = 'schedule.html'; // URL
}