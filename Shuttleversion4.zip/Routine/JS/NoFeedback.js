function handleNoClick() {
    window.location.href = 'feedback.html'; // Redirect to feedback page
}