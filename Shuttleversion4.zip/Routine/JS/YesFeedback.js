function handleYesClick() {
    // Display confirmation message
    //alert("Glad we could help!");
    window.location.href = 'Thankyou.html'; // Redirect to feedback page

};
