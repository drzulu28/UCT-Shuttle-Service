function handleSubmitClick() {
    window.location.href = 'Thankyou.html'; // Redirect to feedback page
}